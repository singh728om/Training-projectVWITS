use HRMS;
/*Create table of Employee, Attanddance,Applicant,Leave request In Normalized form */

Create table Employee(EmpID int primary key,FirstName varchar(10),LastName varchar(10),Address Varchar(10),ContactNo int)
Create table Attandance(AttnID int primary key,EmpID int foreign key references Employee,DateofAttd date,presentAbsent bit,DateTimePunchedIn datetime default CURRENT_TIMESTAMP,DateTimePunchedOut datetime default CURRENT_TIMESTAMP)
Create table Applicant(AppID int Primary key,applicant_name varchar(10),Applicant_Location varchar(10),MobileNo int,jobID Varchar(4))
Create table LeaveRequest(LeaveID int primary key,EmpID int foreign key references Employee,StartDate datetime default CURRENT_TIMESTAMP,EndDate datetime default CURRENT_TIMESTAMP,No_HalfDays int)

/*Insertion of values into Employee table */

Insert into Employee values('1021','Abhishek','Singh','Mirzapur','10298312')
Insert into Employee values('1022','Jyoti','Mishra','Varansi','17698312')
Insert into Employee values('1023','Saloni','Singh','Jhansi','10290912')
Insert into Employee values('1024','Abhimanyu','Dwivedi','Lucknow','99898312')
Insert into Employee values('1025','Monika','Sharma','Mathura','43298312')
Insert into Employee values('1026','Abhishek','Singh','Noida','98798312')
Insert into Employee values('1027','Jyoti','Singh','Prayagraj','23498312')

select*from Employee

/*Insertion of values into Attandance table */

Insert into Attandance values('1121','1021','2021-09-09','1','2021-09-08','2021-09-08')
Insert into Attandance values('1122','1022','2021-09-09','0','2021-09-08','2021-09-08')
Insert into Attandance values('1123','1023','2021-09-09','1','2021-09-08','2021-09-08')
Insert into Attandance values('1124','1024','2021-09-09','0','2021-09-08','2021-09-08')
Insert into Attandance values('1125','1025','2021-09-09','1','2021-09-08','2021-09-08')
Insert into Attandance values('1126','1026','2021-09-09','0','2021-09-08','2021-09-08')


select*from Attandance

/*Insertion of values into Applicant  table */

Insert into Applicant values('1021','Abhishek','Mirzapur','10298312','A21')
Insert into Applicant values('1022','Jyoti','Varansi','17698312','E21')
Insert into Applicant values('1023','Saloni','Jhansi','10290912','D21')
Insert into Applicant values('1024','Abhimanyu','Lucknow','99898312','A21')
Insert into Applicant values('1025','Monika','Mathura','43298312','E21')
Insert into Applicant values('1026','Abhishek','Noida','98798312','D21')
Insert into Applicant values('1027','Jyoti','Prayagraj','23498312','B21')

Select*from Applicant

/*Insertion of values into Leave Request  table */

Insert into LeaveRequest values('201','1021','2021-09-09','2021-09-08','2')
Insert into LeaveRequest values('202','1022','2021-09-09','2021-09-08','1')
Insert into LeaveRequest values('203','1023','2021-09-09','2021-09-08','3')
Insert into LeaveRequest values('204','1024','2021-09-09','2021-09-08','4')
Insert into LeaveRequest values('205','1025','2021-09-09','2021-09-08','0')
Insert into LeaveRequest values('206','1026','2021-09-09','2021-09-08','1')
Insert into LeaveRequest values('207','1027','2021-09-09','2021-09-08','3')

select*from LeaveRequest